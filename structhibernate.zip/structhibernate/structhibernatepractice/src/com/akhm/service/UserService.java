package com.akhm.service;

import com.akhm.service.dto.UserDTO;

public interface UserService {
	public Integer saveuser(UserDTO userDTO);

}
