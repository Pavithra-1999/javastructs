package com.akhm.dao;

import com.akhm.dao.model.UserTl;

public interface UserDAO {
	public Integer insertUser(UserTl userTl);

}
